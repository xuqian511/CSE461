# CSE461 part1 :Client readme
## version
python 3.7
## Members
- Hung Lo: honkuro
- Alex Lee : alee217
- Neil Jurling : ndj0613

## Secrets (Stage A, Stage B, Stage C, Stage D)
Secret A=32
Secret B=27
Secret C=33
Secret D=53

## How to Compile
Run
```
python3 part1.py
```