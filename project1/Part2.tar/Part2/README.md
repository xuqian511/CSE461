#Server side:
## version
python 3.7
## Members
- Hung Lo: honkuro
- Alex Lee : alee217
- Neil Jurling : ndj0613
## How to compile
spin the server
```
python3 part2server.py
```
then run the client (which just modify the Domain from attu to our local server)
```
python3 part2client.py
```