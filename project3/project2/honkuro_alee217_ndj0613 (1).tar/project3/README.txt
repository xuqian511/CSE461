Hung Lo : honkuro
Alex Lee : alee217
Neil Jurling : ndj0613

Instruction:
Configure firefox as shown in section.
Use the run script to run.
The run script takes a port number as argument.
For example:
./run 12345

Code tested on python 3.6.7 and 3.7.3.
If your python 3 executable is not python3, then just change the 
python3 part in the run script to your executable name for python 3.